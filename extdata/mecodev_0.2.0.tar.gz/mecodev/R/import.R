#' @import ggplot2
#' @import vegan
#' @import microeco
#' @importFrom magrittr %<>%
#' @importFrom magrittr %>%
#' @importFrom R6 R6Class
NULL
