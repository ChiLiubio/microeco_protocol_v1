library(testthat)
library(SparseDOSSA2)

test_check("SparseDOSSA2")
